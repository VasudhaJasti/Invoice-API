export const devConfig = {
  port: 3000,
  database: 'invoice-builder',
  secret: 'AHSDEUIYEIUER',
  frontendURL: 'http://localhost:4200',
  google: {
    clientId: '997480597041-i9bdl1bh3dl52tu53vks0744sdo2816h.apps.googleusercontent.com',
    clientSecret: 'QL2s6_41I2nVLU9qbPLdOJtd',
    callbackURL: 'http://localhost:3000/api/auth/google/callback',
  },
  twitter: {
    consumerKey: 'dFRt0qpQ564CfsRj2Q8CzztdB',
    consumerSecret: 'ymhQctr7r6FYTWKfcKG1FjPQGyHTTBdeIOvP8h3f301UpgA1VT',
    callbackURL: 'http://localhost:3000/api/auth/twitter/callback',
  },
  github: {
    clientId: '6853573195b9a142b1f4',
    clientSecret: '3de8c608fd94b91b604bc71bf7e6e191f5afd60b',
    callbackURL: 'http://localhost:3000/api/auth/github/callback',
  },

  ethereal: {
    username: 'ursula54@ethereal.email',
    password: 'krDz7sdtfgCxSngg2s',
    host: 'smtp.ethereal.email',
    port: 587,
  },
};
